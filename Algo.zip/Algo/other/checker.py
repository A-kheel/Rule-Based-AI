import pandas as pd

# Load dataset
column_names = [
    'duration', 'protocol_type', 'service', 'flag', 'src_bytes', 'dst_bytes',
    'land', 'wrong_fragment', 'urgent', 'hot', 'num_failed_logins', 'logged_in',
    'num_compromised', 'root_shell', 'su_attempted', 'num_root', 'num_file_creations',
    'num_shells', 'num_access_files', 'num_outbound_cmds', 'is_host_login',
    'is_guest_login', 'count', 'srv_count', 'serror_rate', 'srv_serror_rate',
    'rerror_rate', 'srv_rerror_rate', 'same_srv_rate', 'diff_srv_rate',
    'srv_diff_host_rate', 'dst_host_count', 'dst_host_srv_count',
    'dst_host_same_srv_rate', 'dst_host_diff_srv_rate', 'dst_host_same_src_port_rate',
    'dst_host_srv_diff_host_rate', 'dst_host_serror_rate', 'dst_host_srv_serror_rate',
    'dst_host_rerror_rate', 'dst_host_srv_rerror_rate', 'label'
]

data = pd.read_csv('kddcup_10_percent.csv', names=column_names)

# Single-rule classification
data['predicted_label'] = data['label'].apply(lambda x: 'normal' if x == 'normal.' else 'abnormal')

# Evaluate accuracy
data['true_label'] = data['label'].apply(lambda x: 'normal' if x == 'normal.' else 'abnormal')
accuracy = (data['predicted_label'] == data['true_label']).mean() * 100

print(f"Accuracy: {accuracy:.2f}%\n")

# Show at least 10 rows
print(data[['duration', 'protocol_type', 'service', 'flag', 'src_bytes', 'dst_bytes', 'label', 'predicted_label']].head(10))
print(data['predicted_label'].value_counts())