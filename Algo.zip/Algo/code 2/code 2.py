import pandas as pd
# ===============================================================
# Created by ChatGPT (GPT-5 mini)
# This code classifies network connections from the KDD Cup 1999 dataset
# as 'normal' or 'abnormal' using 10 rule-based heuristics:
# 1. Abnormal login attempts
# 2. Suspicious TCP flags
# 3. Hot indicators / system compromise
# 4. High connection counts
# 5. Large data transfers
# 6. Rare services
# 7. Land attack
# 8. Wrong fragment / urgent packets
# 9. Guest login abuse
# 10. Rare connection patterns
# ===============================================================

# Load the KDD Cup 1999 dataset
column_names = [
    'duration', 'protocol_type', 'service', 'flag', 'src_bytes', 'dst_bytes',
    'land', 'wrong_fragment', 'urgent', 'hot', 'num_failed_logins', 'logged_in',
    'num_compromised', 'root_shell', 'su_attempted', 'num_root', 'num_file_creations',
    'num_shells', 'num_access_files', 'num_outbound_cmds', 'is_host_login',
    'is_guest_login', 'count', 'srv_count', 'serror_rate', 'srv_serror_rate',
    'rerror_rate', 'srv_rerror_rate', 'same_srv_rate', 'diff_srv_rate',
    'srv_diff_host_rate', 'dst_host_count', 'dst_host_srv_count',
    'dst_host_same_srv_rate', 'dst_host_diff_srv_rate', 'dst_host_same_src_port_rate',
    'dst_host_srv_diff_host_rate', 'dst_host_serror_rate', 'dst_host_srv_serror_rate',
    'dst_host_rerror_rate', 'dst_host_srv_rerror_rate', 'label'
]

data = pd.read_csv('kddcup_10_percent.csv', names=column_names)

# Convert numeric columns to correct type
numeric_cols = [
    'duration', 'src_bytes', 'dst_bytes', 'wrong_fragment', 'urgent', 'hot',
    'num_failed_logins', 'logged_in', 'num_compromised', 'root_shell',
    'su_attempted', 'num_root', 'num_file_creations', 'num_shells',
    'num_access_files', 'num_outbound_cmds', 'is_host_login', 'is_guest_login',
    'count', 'srv_count', 'serror_rate', 'srv_serror_rate', 'rerror_rate',
    'srv_rerror_rate', 'same_srv_rate', 'diff_srv_rate', 'srv_diff_host_rate',
    'dst_host_count', 'dst_host_srv_count', 'dst_host_same_srv_rate',
    'dst_host_diff_srv_rate', 'dst_host_same_src_port_rate',
    'dst_host_srv_diff_host_rate', 'dst_host_serror_rate',
    'dst_host_srv_serror_rate', 'dst_host_rerror_rate', 'dst_host_srv_rerror_rate'
]

for col in numeric_cols:
    data[col] = pd.to_numeric(data[col], errors='coerce')

# Drop rows with NaN in numeric columns
data = data.dropna(subset=numeric_cols)

# Rule-based classifier function
def classify(record):
    # Rule 1: Abnormal login attempts
    if record['logged_in'] == 0 and record['num_failed_logins'] > 0:
        return 'abnormal'
    
    # Rule 2: Suspicious TCP flags
    attack_flags = ['REJ', 'RSTO', 'RSTOS0', 'RSTR', 'SH', 'S0', 'S1', 'S2', 'S3']
    if record['flag'] in attack_flags:
        return 'abnormal'
    
    # Rule 3: Hot indicators / system compromise
    if record['hot'] > 0 or record['num_compromised'] > 0 or record['root_shell'] > 0 or record['su_attempted'] > 0:
        return 'abnormal'
    
    # Rule 4: High connection counts
    if record['count'] > 100 or record['srv_count'] > 100:
        return 'abnormal'
    
    # Rule 5: Large data transfers
    if record['src_bytes'] > 1_000_000 or record['dst_bytes'] > 1_000_000:
        return 'abnormal'
    
    # Rule 6: Rare services
    rare_services = ['urh', 'X11', 'red_i', 'pm_dump']
    if record['service'] in rare_services:
        return 'abnormal'
    
    # Rule 7: Land attack
    if record['land'] == 1:
        return 'abnormal'
    
    # Rule 8: Wrong fragment / urgent packets
    if record['wrong_fragment'] > 0 or record['urgent'] > 0:
        return 'abnormal'
    
    # Rule 9: Guest login abuse
    if record['is_guest_login'] == 1 and record['num_root'] > 0:
        return 'abnormal'
    
    # Rule 10: Rare connection patterns
    if record['dst_host_srv_diff_host_rate'] > 0.5 or record['same_srv_rate'] < 0.1:
        return 'abnormal'
    
    # Default: normal
    return 'normal'

# Apply classifier
data['predicted_label'] = data.apply(classify, axis=1)

# Count predictions
print(data['predicted_label'].value_counts())
